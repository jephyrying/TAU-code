import math
from collections import OrderedDict

import torch
import torch.nn.functional as F
from torch import nn
import sys
sys.path.append('./')
sys.path.append('../')
from .tps_spatial_transformer import TPSSpatialTransformer
from .stn_head import STNHead
from .transformer_v2 import InfoTransformer
from .transformer_v2 import PositionalEncoding
from .amm import AMM
from .arm import ARM


class Text_Aware_Upsampling(nn.Module):
    def __init__(self, in_channels, up_channels,up_scale):
        super(Text_Aware_Upsampling, self).__init__()
        self.pixelshuffle= Pixelsh(up_channels,up_scale)
        self.edge_feature= Edge_Aware_Branch(in_channels,up_channels,up_scale)
        self.semantic_feature = Text_Aware_Branch(in_channels,up_channels,up_scale)
        # self.up_scale = 4
        self.up_scale = up_scale
        self.ASF3 = Adaptive_Spatial_Fusion()
        # self.ASF2 = Adaptive_Spatial_Fusion2()
        # self.bn = nn.BatchNorm2d(up_channels)
        self.prelu = Prelu()

    def forward(self, x , y): #x为初级特征，y为原输入
        y = self.pixelshuffle(y)
        edge_feature = self.edge_feature(x,self.up_scale)
        semantic_feature = self.semantic_feature(x)
        # out = self.ASF2(semantic_feature,y)
        out = self.ASF3(edge_feature,semantic_feature,y)
        out = self.prelu(out)

        return out

class Gru_module(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Gru_module, self).__init__()
        assert out_channels % 2 == 0
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=1, padding=0)
        self.gru = nn.GRU(out_channels, out_channels // 2, bidirectional=True, batch_first=True)

    def forward(self, x):
        x = self.conv1(x)
        x = x.permute(0, 2, 3, 1).contiguous()
        b = x.size()
        x = x.view(b[0] * b[1], b[2], b[3])
        x, _ = self.gru(x)
        # x = self.gru(x)[0]
        x = x.view(b[0], b[1], b[2], b[3])
        x = x.permute(0, 3, 1, 2)
        return x

class Text_Aware_Branch(nn.Module):
    def __init__(self, in_channels,out_channels,up_scale):
        super(Text_Aware_Branch, self).__init__()
        self.up_bilinear = nn.Upsample(scale_factor=up_scale, mode='bilinear', align_corners=True)
        self.conv0 = nn.Sequential(nn.Conv2d(in_channels, 64, kernel_size=5,stride=1, padding=2),
                                   nn.PReLU())
        self.gru = Gru_module(64,64)
        self.conv = nn.Sequential(nn.Conv2d(128, out_channels, kernel_size=3,padding=1),
                     nn.PReLU())

        # self.conv = nn.Sequential(nn.Conv2d(128, out_channels, kernel_size=3,stride=2, padding=1),
        #              nn.PReLU())

    def forward(self, x):

        x = self.up_bilinear(x)
        x = self.conv0(x)
        # h v
        x1 = self.gru(x)
        x1 = x1.transpose(-1, -2)
        x1 = self.gru(x1)
        x1 = x1.transpose(-1, -2)
        # v h
        x2 = x.transpose(-1, -2)
        x2 = self.gru(x2)
        x2 = x2.transpose(-1, -2)
        x2 = self.gru(x2)

        out = torch.cat((x1, x2), 1)
        out = self.conv(out) #统一size
        # print("textaware")
        # print(out.shape)
        # out = x + out
        return out

# pixel shuffle
class Pixelsh(nn.Module):
    def __init__(self, in_channels, up_scale):
        super(Pixelsh, self).__init__()
        self.conv = nn.Conv2d(in_channels, in_channels * up_scale ** 2, kernel_size=3, padding=1)

        self.pixel_shuffle = nn.PixelShuffle(up_scale)
        # self.prelu = nn.ReLU()
        self.prelu = Prelu()

    def forward(self, x):
        x = self.conv(x)
        x = self.pixel_shuffle(x)
        # x = self.prelu(x)
        return x

class Prelu(nn.Module):
    def __init__(self, ):
        super(Prelu, self).__init__()
        self.activated = True
    def forward(self, x):
        if self.activated:
            x = x * (torch.tanh(F.softplus(x)))
        return x

# 方便起见，定义基础卷积：
def BasicConv(channel_in, channel_out, kernel_size, stride=1, padding=None):
    if not padding:
        padding = (kernel_size - 1) // 2 if kernel_size else 0
    else:
        padding = padding
    return nn.Sequential(OrderedDict([
        ("conv", nn.Conv2d(channel_in, channel_out, kernel_size=kernel_size, stride=stride, padding=padding, bias=False)),
        # ("bn", nn.BatchNorm2d(channel_out)),
        ("relu", Prelu()),
    ]))

# 定义一个3x3的拉普拉斯核：
class LaplacianFilter(nn.Module):
    def __init__(self, in_channels):
        super(LaplacianFilter, self).__init__()
        # 定义一个3x3的拉普拉斯核，每个输入通道一个
        kernel_size = 3
        # 创建一个形状为 (in_channels, 1, 3, 3) 的拉普拉斯核
        self.laplace_kernel = nn.Parameter(torch.tensor([
            [0, 1, 0],
            [1, -4, 1],
            [0, 1, 0]
        ], dtype=torch.float32).view(1, 1, kernel_size, kernel_size).repeat(in_channels, 1, 1, 1), requires_grad=False)

    def forward(self, x):
        # 应用拉普拉斯算子，groups参数使得卷积在每个通道上独立进行
        # 然后沿着通道维度求和，以得到单通道输出
        edge_strength = F.conv2d(x, self.laplace_kernel, padding=1, groups=x.shape[1]).sum(dim=1, keepdim=True)
        # edge_strength = torch.clamp(edge_strength, min=0, max=1)
        return edge_strength

# 门控融合：
class GatedUnit(nn.Module):
    def __init__(self, ):
        super(GatedUnit, self).__init__()
        self.weight1 = torch.nn.Parameter(torch.FloatTensor(1), requires_grad=True)
        self.weight2 = torch.nn.Parameter(torch.FloatTensor(1), requires_grad=True)
        self.weight3 = torch.nn.Parameter(torch.FloatTensor(1), requires_grad=True)
        self.weight4 = torch.nn.Parameter(torch.FloatTensor(1), requires_grad=True)
        self.weight5 = torch.nn.Parameter(torch.FloatTensor(1), requires_grad=True)
        self.weight1.data.fill_(1)
        self.weight2.data.fill_(1)
        self.weight3.data.fill_(1)
        self.weight4.data.fill_(1)
        self.weight5.data.fill_(1)

    def forward(self, feature1, feature2, feature3,feature4,feature5):
        return self.weight1 * feature1+ self.weight2 * feature2+ self.weight3 * feature3+ self.weight4 * feature4+ self.weight5 * feature5

# 高频信息分支：
class Edge_Aware_Branch(nn.Module):
    def __init__(self, in_channels,out_channels,up_scale):
        super(Edge_Aware_Branch, self).__init__()
        self.up_bilinear = nn.Upsample(scale_factor=up_scale, mode='bilinear', align_corners=True)
        self.lap = LaplacianFilter(in_channels)

        self.conv1 = nn.Sequential(nn.Conv2d(in_channels, 32, kernel_size=3, padding=1),
                                   nn.PReLU())
        self.conv2 = BasicConv(64, 128, kernel_size=3, stride=2, padding=1)
        self.conv3 = BasicConv(128, 256, kernel_size=3, stride=2, padding=1)
        self.conv4 = BasicConv(256, 512, kernel_size=3, stride=2, padding=1)

        list_k = [[64, 128, 64, 3, 1], [128, 256, 128, 3, 1], [256, 512, 256, 3, 1],[512, 0, 512, 3, 1]]
        self.unet = Edge_Unet(list_k)
        self.gate = GatedUnit()
        self.conv5 = nn.Sequential(nn.Conv2d(32, out_channels, kernel_size=3,padding=1),
                     nn.PReLU())
        # self.conv5 = nn.Sequential(nn.Conv2d(32, out_channels, kernel_size=3,stride=2, padding=1),
        #              nn.PReLU())
        self.cbam = CBAM(32)
        self.bn = nn.BatchNorm2d(32)
        # self.conv123 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=2, padding=1)

    def forward(self, x, up_scale):
        b,c,h,w = x.size()
        x_size = (h * up_scale, w * up_scale)  # final size
        # print(x_size)
        x = self.up_bilinear(x)
        edge = self.lap(x)
        # print(edge.shape)
        c0 = self.conv1(x)  # (b, 32, 32, 128)

        c0 = self.cbam(c0)

        c1 = torch.cat((c0, edge * c0), 1) # (b, 64, 32, 128)

        c2 = self.conv2(c1)  # (b, 128, 16, 64)
        c3 = self.conv3(c2)  # (b, 256, 8, 32)
        c4 = self.conv4(c3)  # (b, 512, 4, 16)

        feature_maps = [c1, c2, c3, c4]
        score_maps= self.unet(feature_maps, x_size)
        final_score_maps = self.gate(*score_maps, edge ) # 加权融合
        final_score_maps = torch.sigmoid(final_score_maps)
        out = final_score_maps * c0 + c0 # 试一下要不要 +
        # out = final_score_maps * c0
        out = self.conv5(out) #统一size
        # print(out.shape)
        # print("edgeaware")
        # print(out.shape)
        return out

class Edge_Unet(nn.Module):
    def __init__(self, list_k):
        super(Edge_Unet, self).__init__()
        self.list_k = list_k
        trans, up, score = [], [], []
        for ik in list_k:
            if ik[1] > 0:
                trans.append(nn.Sequential(
                    nn.Conv2d(ik[1], ik[0], 1, 1, bias=False),
                    nn.ReLU(inplace=True)
                ))
            up.append(nn.Sequential(
                nn.Conv2d(ik[0], ik[2], ik[3], 1, ik[4]),
                nn.ReLU(inplace=True),
                nn.Conv2d(ik[2], ik[2], ik[3], 1, ik[4]),
                nn.ReLU(inplace=True),
                nn.Conv2d(ik[2], ik[2], ik[3], 1, ik[4]),
                nn.ReLU(inplace=True)))
            score.append(nn.Conv2d(ik[2], 1, 3, 1, 1))
        trans.append(nn.Sequential(
            nn.Conv2d(512, 64, 1, 1, bias=False),
            nn.ReLU(inplace=True)
        ))
        self.trans, self.up, self.score = nn.ModuleList(trans), nn.ModuleList(up), nn.ModuleList(score)
        self.relu = nn.ReLU()

    def forward(self, list_x, x_size):
        up_sal,  sal_feature = [], []
        num_f = len(list_x)
        tmp = self.up[num_f - 1](list_x[num_f - 1])
        sal_feature.append(tmp)
        U_tmp = tmp
        up_sal.append(F.interpolate(self.score[num_f - 1](tmp), x_size, mode='bilinear', align_corners=True))
        # 从倒数第二个特征图开始，逐层向上进行特征融合和上采样
        for j in range(2, num_f):
            i = num_f - j
            if list_x[i].size()[1] < U_tmp.size()[1]:
                U_tmp = list_x[i] + F.interpolate((self.trans[i](U_tmp)), list_x[i].size()[2:], mode='bilinear',
                                                  align_corners=True)
            else:
                U_tmp = list_x[i] + F.interpolate((U_tmp), list_x[i].size()[2:], mode='bilinear', align_corners=True)
            tmp = self.up[i](U_tmp)
            U_tmp = tmp
            sal_feature.append(tmp)
            up_sal.append(F.interpolate(self.score[i](tmp), x_size, mode='bilinear', align_corners=True))
        # 处理第一个特征图
        U_tmp = list_x[0] + F.interpolate((self.trans[-1](sal_feature[0])), list_x[0].size()[2:], mode='bilinear',
                                          align_corners=True)
        tmp = self.up[0](U_tmp)
        up_sal.append(F.interpolate(self.score[0](tmp), x_size, mode='bilinear', align_corners=True))
        # 返回边缘特征列表
        return up_sal

class Channel_Attention(nn.Module):
    def __init__(self, gate_channels, reduction_ratio=16):
        super(Channel_Attention, self).__init__()
        self.gate_channels = gate_channels
        self.mlp = nn.Sequential(
            nn.Flatten(),
            nn.Linear(gate_channels, gate_channels // reduction_ratio),
            nn.ReLU(),
            nn.Linear(gate_channels // reduction_ratio, gate_channels)
        )

    def forward(self, x):
        avg_out = self.mlp(F.avg_pool2d(x, (x.size(2), x.size(3)), stride=(x.size(2), x.size(3))))
        max_out = self.mlp(F.max_pool2d(x, (x.size(2), x.size(3)), stride=(x.size(2), x.size(3))))
        channel_att_sum = avg_out + max_out

        scale = torch.sigmoid(channel_att_sum).unsqueeze(2).unsqueeze(3).expand_as(x)
        return x * scale


class Spatial_Attention(nn.Module):
    def __init__(self):
        super(Spatial_Attention, self).__init__()
        kernel_size = 7
        self.spatial = nn.Conv2d(2, 1, kernel_size, stride=1, padding=(kernel_size - 1) // 2)

    def forward(self, x):
        x_compress = torch.cat((torch.max(x, 1)[0].unsqueeze(1), torch.mean(x, 1).unsqueeze(1)), dim=1)
        x_out = self.spatial(x_compress)
        scale = torch.sigmoid(x_out)
        return x * scale


class CBAM(nn.Module):
    def __init__(self, gate_channels, reduction_ratio=16):
        super(CBAM, self).__init__()
        self.ChannelGate = Channel_Attention(gate_channels, reduction_ratio)
        self.SpatialGate = Spatial_Attention()

    def forward(self, x):
        x_out = self.ChannelGate(x)
        x_out = self.SpatialGate(x_out)
        return x_out


def CompresionnConv(channel_in, channel_out, kernel_size, stride=1, padding=None):
    if not padding:
        padding = (kernel_size - 1) // 2 if kernel_size else 0
    else:
        padding = padding
    return nn.Sequential(OrderedDict([
        ("conv", nn.Conv2d(channel_in, channel_out, kernel_size=kernel_size, stride=stride, padding=padding, bias=False)),
        ("bn", nn.BatchNorm2d(channel_out)),
        ("relu", nn.ReLU(inplace=True)),
    ]))


# adaptive spatial fusion:
class Adaptive_Spatial_Fusion(nn.Module):
    def __init__(self, inter_dim=64):
        super(Adaptive_Spatial_Fusion, self).__init__()
        self.inter_dim = inter_dim
        compress_c = 8

        self.weight_level_1 = CompresionnConv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_2 = CompresionnConv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_3 = CompresionnConv(self.inter_dim, compress_c, 1, 1)

        self.weight_levels = nn.Conv2d(compress_c * 3, 3, kernel_size=1, stride=1, padding=0)

        self.conv = nn.Conv2d(self.inter_dim, self.inter_dim, kernel_size=3, padding=1)

    def forward(self, input1, input2, input3):

        level_1_weight_v = self.weight_level_1(input1)
        level_2_weight_v = self.weight_level_2(input2)
        level_3_weight_v = self.weight_level_3(input3)

        levels_weight_v = torch.cat((level_1_weight_v, level_2_weight_v, level_3_weight_v), 1)
        levels_weight = self.weight_levels(levels_weight_v)
        levels_weight = F.softmax(levels_weight, dim=1)

        fused_out_reduced = input1 * levels_weight[:, 0:1, :, :] + \
                            input2 * levels_weight[:, 1:2, :, :] + \
                            input3 * levels_weight[:, 2:, :, :]
        out = self.conv(fused_out_reduced)

        return out

# 消融实验 两个特征图的ASF
class Adaptive_Spatial_Fusion2(nn.Module):
    def __init__(self, inter_dim=64):
        super(Adaptive_Spatial_Fusion2, self).__init__()
        self.inter_dim = inter_dim
        compress_c = 8

        self.weight_level_1 = BasicConv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_2 = BasicConv(self.inter_dim, compress_c, 1, 1)


        self.weight_levels = nn.Conv2d(compress_c * 2, 2, kernel_size=1, stride=1, padding=0)

        # self.conv = BasicConv(self.inter_dim, self.inter_dim, 3, 1)
        self.conv = nn.Conv2d(self.inter_dim, self.inter_dim, kernel_size=3, padding=1)
        # self.bn = nn.BatchNorm2d(self.inter_dim)
        self.prelu = Prelu()


    def forward(self, input1, input2):

        level_1_weight_v = self.weight_level_1(input1)
        level_2_weight_v = self.weight_level_2(input2)

        levels_weight_v = torch.cat((level_1_weight_v, level_2_weight_v), 1)
        levels_weight = self.weight_levels(levels_weight_v)
        levels_weight = F.softmax(levels_weight, dim=1)

        fused_out_reduced = input1 * levels_weight[:, 0:1, :, :] + \
                            input2 * levels_weight[:, 1:2, :, :]
        # out = fused_out_reduced
        out = self.conv(fused_out_reduced)
        # out = self.prelu(out)
        return out



class PEAN(nn.Module):

    def __init__(self, scale_factor=2, width=128, height=32, STN=False, srb_nums=5, mask=True, hidden_units=32, testing=False):
        super(PEAN, self).__init__()
        in_planes = 3
        if mask:
            in_planes = 4
        assert math.log(scale_factor, 2) % 1 == 0
        upsample_block_num = int(math.log(scale_factor, 2))
        self.block1 = nn.Sequential(    
            nn.Conv2d(in_planes, 2*hidden_units, kernel_size=9, padding=4),
            nn.PReLU()                  
        )
        self.srb_nums = srb_nums
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.prior_dim = 2*hidden_units
        self.block2 = AMM()
        
        setattr(self, 'block%d' % (srb_nums + 2),
                nn.Sequential(
                    nn.Conv2d(2*hidden_units, 2*hidden_units, kernel_size=3, padding=1),
                    nn.BatchNorm2d(2*hidden_units)
                ))

        self.block_up = Text_Aware_Upsampling(in_planes,2 * hidden_units, 2)
        # setattr(self, 'block%d' % (srb_nums + 3), nn.Sequential(nn.Conv2d(2 * hidden_units, in_planes, kernel_size=9, padding=4)))

        # block_ = [UpsampleBLock(2*hidden_units, 2*hidden_units, scale_factor) for _ in range(upsample_block_num)]
        block_ = [nn.Conv2d(2 * hidden_units, in_planes, kernel_size=9, padding=4), nn.BatchNorm2d(in_planes)]
        # block_.append(nn.Conv2d(2*hidden_units, in_planes, kernel_size=9, padding=4))
        setattr(self, 'block%d' % (srb_nums + 3), nn.Sequential(*block_))
        self.tps_inputsize = [32, 64]       
        tps_outputsize = [height//scale_factor, width//scale_factor]
        num_control_points = 20
        tps_margins = [0.05, 0.05]
        self.stn = STN
        t_decoder_num = 3
        self.fn = nn.Linear(95, self.prior_dim)
        self.pe = PositionalEncoding(d_model=self.prior_dim, dropout=0.1, max_len=5000)
        self.init_factor = nn.Embedding(tps_outputsize[0]*tps_outputsize[1], self.prior_dim)
        self.upsample_transformer = InfoTransformer(d_model=self.prior_dim,
                                    dropout=0.1,
                                    num_encoder_layers=3,
                                    nhead=4,
                                    dim_feedforward=self.prior_dim,
                                    num_decoder_layers=t_decoder_num,
                                    normalize_before=False,
                                    return_intermediate_dec=True, feat_height=tps_outputsize[0], feat_width=tps_outputsize[1])

        if self.stn:
            self.tps = TPSSpatialTransformer(
                output_image_size=tuple(tps_outputsize),
                num_control_points=num_control_points,
                margins=tuple(tps_margins))

            self.stn_head = STNHead(
                in_planes=in_planes,
                num_ctrlpoints=num_control_points,
                activation='none')
        self.testing = testing
        if not self.testing:
            self.arm = ARM(16, 1, 37, 256)

    def forward(self, x, rec_result):

        if self.stn and self.training:
            x = F.interpolate(x, self.tps_inputsize, mode='bilinear', align_corners=True)
            _, ctrl_points_x = self.stn_head(x)
            x, _ = self.tps(x, ctrl_points_x)             

        yuan = x

        block = {'1': self.block1(x)}
        B, _, H, W = block['1'].shape
        x_im = block['1'].contiguous().view(B, -1, H*W).permute(2, 0, 1)
        rec_result = rec_result.transpose(0, 1)
        rec_result = self.fn(rec_result)
        rec_result = F.relu(rec_result)
        L, _, C = rec_result.shape
        prior = rec_result
        x_pos_mem = self.pe(torch.zeros((B, L, C)).to(self.device)).permute(1, 0, 2)
        mask_mem = torch.zeros((B, L)).to(self.device).bool()
        prior, _ = self.upsample_transformer(prior, mask_mem, self.init_factor.weight, x_pos_mem, x_im)
        prior = prior.mean(0)
        prior = prior.permute(1, 2, 0).view(B, -1, H, W)

        for i in range(self.srb_nums):                 
            block[str(i + 2)] = getattr(self, 'block%d' % (i + 2))(block[str(i + 1)], prior)

        block[str(self.srb_nums + 2)] = getattr(self, 'block%d' % (self.srb_nums + 2))(block[str(self.srb_nums + 1)])
        if not self.testing:
            input_feature = torch.nn.functional.interpolate(block[str(self.srb_nums + 2)], (16, 50), mode='bicubic')
            logits = self.arm(input_feature)
        else:
            logits = None

        block_up = self.block_up(yuan, (block['1'] + block[str(self.srb_nums + 2)]))
        block[str(self.srb_nums + 3)] = getattr(self, 'block%d' % (self.srb_nums + 3)) \
            (block_up)

        # block[str(self.srb_nums + 3)] = getattr(self, 'block%d' % (self.srb_nums + 3)) \
        #     ((block['1'] + block[str(self.srb_nums + 2)]))
        output = F.relu(block[str(self.srb_nums + 3)]) 
        return output, logits


class UpsampleBLock(nn.Module):

    def __init__(self, in_channels, out_channels, up_scale):
        super(UpsampleBLock, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels * up_scale ** 2, kernel_size=3, padding=1)
        self.pixel_shuffle = nn.PixelShuffle(up_scale)
        self.prelu = mish()

    def forward(self, x):
        x = self.conv(x)                
        x = self.pixel_shuffle(x)      
        x = self.prelu(x)              
        return x


class mish(nn.Module):
    def __init__(self, ):
        super(mish, self).__init__()
        self.activated = True

    def forward(self, x):
        if self.activated:
            x = x * (torch.tanh(F.softplus(x)))
        return x